
const questions = document.querySelectorAll(".faq-question");

questions.forEach((question) => {
    question.addEventListener("click", () => {
        const answerId = question.getAttribute("aria-controls");
        const answer = document.getElementById(answerId);

        // Fallback: stop if the answer panel is missing
        if (!answer) {
            console.error("FAQ answer panel not found:", answerId);
            return;
        }

        const isExpanded =
            question.getAttribute("aria-expanded") === "true";

        question.setAttribute("aria-expanded", String(!isExpanded));
        answer.hidden = isExpanded;

        const icon = question.querySelector("span");
        if (icon) {
            icon.textContent = isExpanded ? "+" : "−";
        }
    });
});