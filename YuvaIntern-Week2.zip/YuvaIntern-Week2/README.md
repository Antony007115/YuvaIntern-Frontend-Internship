
# Interactive FAQ Accordion

## Project Overview
This project is an interactive FAQ accordion developed
using HTML, CSS, and vanilla JavaScript.

Users can click a question to show or hide its answer.

## Features
- Interactive accordion with three questions
- Click to open and close answers
- Keyboard support using Tab and Enter
- ARIA attributes for accessibility
- Responsive layout for mobile and desktop
- Clear focus indicator for keyboard users

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Project Structure
- index.html
- style.css
- script.js
- README.md

## How to Run
1. Download or clone the project.
2. Open the project folder.
3. Open index.html in a web browser.
4. Click any FAQ question to view its answer.

## Testing
The FAQ questions were tested using mouse clicks
and keyboard navigation. The page was also checked
in a mobile viewport.

## Author
A . Antony Benatict 