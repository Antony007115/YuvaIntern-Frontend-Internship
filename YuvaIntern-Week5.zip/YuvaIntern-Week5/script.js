
"use strict";

const projectTable = document.getElementById("project-table");
const searchInput = document.getElementById("search");
const statusFilter = document.getElementById("status-filter");
const resultMessage = document.getElementById("result-message");

let projects = [];

function updateSummary() {
    document.getElementById("total-projects").textContent = projects.length;

    document.getElementById("completed-projects").textContent =
        projects.filter(project => project.status === "Completed").length;

    document.getElementById("progress-projects").textContent =
        projects.filter(project => project.status === "In Progress").length;
}

function renderProjects() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    const selectedStatus = statusFilter.value;

    const filteredProjects = projects.filter(project => {
        const matchesSearch =
            project.name.toLowerCase().includes(searchTerm) ||
            project.category.toLowerCase().includes(searchTerm);

        const matchesStatus =
            selectedStatus === "all" ||
            project.status === selectedStatus;

        return matchesSearch && matchesStatus;
    });

    projectTable.replaceChildren();

    if (filteredProjects.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 3;
        cell.textContent = "No matching projects found.";
        row.appendChild(cell);
        projectTable.appendChild(row);
    } else {
        filteredProjects.forEach(project => {
            const row = document.createElement("tr");

            const nameCell = document.createElement("td");
            nameCell.textContent = project.name;

            const categoryCell = document.createElement("td");
            categoryCell.textContent = project.category;

            const statusCell = document.createElement("td");
            const badge = document.createElement("span");
            badge.className = "status " +
                project.status.toLowerCase().replaceAll(" ", "-");
            badge.textContent = project.status;

            statusCell.appendChild(badge);
            row.append(nameCell, categoryCell, statusCell);
            projectTable.appendChild(row);
        });
    }

    resultMessage.textContent =
        `${filteredProjects.length} of ${projects.length} projects shown`;
}

async function loadProjects() {
    try {
        const response = await fetch("./projects.json");

        if (!response.ok) {
            throw new Error("Could not load project data.");
        }

        const data = await response.json();

        if (!Array.isArray(data.projects)) {
            throw new Error("Project data format is invalid.");
        }

        projects = data.projects;
        updateSummary();
        renderProjects();
    } catch (error) {
        projectTable.replaceChildren();

        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.colSpan = 3;
        cell.textContent = "Unable to load projects. Please run the site using Live Server.";
        row.appendChild(cell);
        projectTable.appendChild(row);

        resultMessage.textContent = "Project data could not be loaded.";
        console.error(error);
    }
}

searchInput.addEventListener("input", renderProjects);
statusFilter.addEventListener("change", renderProjects);

loadProjects();