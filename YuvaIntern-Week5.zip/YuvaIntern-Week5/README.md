# NovaTech Analytics Dashboard

## Project Overview

NovaTech Analytics Dashboard is a responsive mini web application developed as part of the YuvaIntern Junior Frontend Developer Internship. It displays project information using a static JSON file and provides interactive search and filtering features.

## Features

* Displays total, completed, and in-progress project counts.
* Loads project data dynamically from `data.json`.
* Searches projects by name.
* Filters projects by status.
* Displays project details in a responsive table.
* Supports desktop and mobile screen sizes.
* Includes accessible labels, keyboard focus styles, and a skip link.

## Technologies Used

* HTML5
* CSS3
* JavaScript
* JSON

## How to Run

1. Download or clone the project.
2. Open the project folder in Visual Studio Code.
3. Install the Live Server extension if it is not already installed.
4. Right-click `index.html` and select **Open with Live Server**.
5. Use the search box and status filter to explore the projects.

## Testing

The dashboard was tested using desktop and mobile browser views. Search and status filtering were checked with the sample project data. Lighthouse mobile testing produced these scores:

* Performance: 89
* Accessibility: 100
* Best Practices: 100
* SEO: 100

## Project Structure

* `index.html` — dashboard structure
* `style.css` — styling and responsive layout
* `script.js` — data loading, search, and filtering
* `data.json` — sample project records

## Conclusion

This project demonstrates the integration of HTML, CSS, JavaScript, and JSON to build a responsive and interactive dashboard. It provides a simple way to view project summaries and filter project records.
